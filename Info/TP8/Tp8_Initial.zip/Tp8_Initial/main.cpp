// Imagine++ project
// Project:  Tp9
// Author:   keriven
// Date:     2007/10/23

// Programme TRON

#include "utils.h"

//======================================
// Serpent





//======================================
// Jeu TRON





int main()
{
	const int w=150;
	const int h=100;
	const int z=4;
	openWindow(w*z,h*z);


	endGraphics();
	return 0;
}
