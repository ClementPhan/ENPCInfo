// Imagine++ project
// Project:  Mastermind
// Author:   keriven
// Date:     2007/10/16

#include<iostream>
#include <string>
using namespace std;

// Saisie d'une combinaison au clavier
// (5 chiffres tapes a la suite entre 0 et 3)
// Attention: ajouter le controle du nombre codes entres
//            et de leur valeur
void getCombinaison(int combi[5])
{
    cout << "Votre essai: ";
    string s;
    cin >> s;
    for (int i=0;i<5;i++)
        combi[i]=s[i]-'0';
}

int main()
{
	cout << "MASTERMIND" << endl;


	return 0;
}
