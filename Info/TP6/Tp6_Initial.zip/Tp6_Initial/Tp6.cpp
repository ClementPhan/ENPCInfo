// Imagine++ project
// Project:  Tp7
// Author:   keriven
// Date:     2007/10/23

#include <Imagine/Graphics.h>
using namespace Imagine;

int main()
{
	const int W=300,H=200;
	openWindow(W,H);

	byte grey[W*H];
	// Remplir grey ici
	putGreyImage(0,0,grey,W,H);

	endGraphics();
	return 0;
}
